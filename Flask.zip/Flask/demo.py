from flask import Flask, render_template, request
import os

app = Flask(__name__)

@app.route('/')
def index():
	return render_template("index.html")

@app.route('/queryProcess', methods=['GET', 'POST'])
def queryProcess():
	if request.method == 'POST':
		query = request.form['query']
		token = query.split(' ')
		preposition = ['in', 'on', 'to', 'of', 'for', 'that', 'the', 'with', 'by', 'at', 'a', 'is', 'what', 'where', 'how']

		processedToken = [elem for elem in token if elem not in preposition]

		if 'list' in [x.lower() for x in processedToken]:

			facultyWebpages = ['www.karunya.edu/english/facultyprofile', 'www.karunya.edu/nanotechnology/facultyprofile', 'www.karunya.edu/maths/faculty', 'www.karunya.edu/emt/faculty', 'www.karunya.edu/eee/faculty', 'www.karunya.edu/civil/faculty', 'www.karunya.edu/agriculture/faculty', 'www.karunya.edu/cst/faculty', 'www.karunya.edu/ece/faculty', 'www.karunya.edu/mechanical/faculty', 'www.karunya.edu/bioinformatics/faculty', 'www.karunya.edu/eie/faculty', 'www.karunya.edu/chemistry/faculty']

			d = {}

			for item in facultyWebpages:
				d[item] = 0
			if processedToken != None:
				for i in range(len(processedToken)):
					for j in range(len(facultyWebpages)):
						if facultyWebpages[j].find(processedToken[i]) != -1:
							value = d.get(facultyWebpages[j])
							d[facultyWebpages[j]] = value + 1

			start_url = max(d, key=d.get)
			system_command = 'scrapy runspider grab.py -a url=http://' + start_url + ' -o static/feb.json'
			os.system("cd ~/Desktop/Flask")
			os.system("rm static/feb.json")
			os.system(system_command)
			return render_template('query-process.html', query=system_command)
		else:
			return render_template('query-process.html',query='Given query cant be processed. Under Development!')
	return render_template('index.html')

if __name__ == "__main__":
	app.run(debug=True)