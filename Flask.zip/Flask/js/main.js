var ourRequest = new XMLHttpRequest();
ourRequest.open('GET', '../feb.json');
ourRequest.onload = function() {
	console.log(ourRequest.responseText);
};
ourRequest.send();