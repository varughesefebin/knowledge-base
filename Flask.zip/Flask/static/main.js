console.log('Febin');

var ourRequest = new XMLHttpRequest();
ourRequest.open('GET', '../feb.json');
console.log("febin");
ourRequest.onload = function() {
	var ourData = ourRequest.responseText;
	console.log(ourData[0]);
	console.log("febin in");
};
ourRequest.send();