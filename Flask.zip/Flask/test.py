text = 'bro'
txt = 'hello febin' + text + ' check again'

print txt