# -*- coding: utf-8 -*-
import scrapy

from scrapy import Spider


class GrabSpider(Spider):
    name = 'grab'
    allowed_domains = ['karunya.edu/cst/faculty']
    start_urls = ['http://karunya.edu/cst/faculty/']

    def parse(self, response):
        container = response.xpath('//*[@class="testimonial-author"]')
        for contain in container:
        	faculty_name = contain.xpath('.//strong/text()').extract_first()
        	designation = contain.xpath('.//span/text()').extract_first()

        	yield{'Name': faculty_name, 'Designation': designation}

	# def close(self, reason):
	# 	csv_file = max(glob.iglob('*.csv'), key=os.path.getctime)

	# 	mydb = MySQLdb.connect(host='localhost', user='root', passwd=null, db='faculty')

	# 	cursor = mydb.cursor()

	# 	csv_data = csv.reader(file(csv_file))

	# 	row_count = 0
	# 	for row in csv_data:
	# 		if row_count != 0:
	# 			cursor.execute('INSERT IGNORE INTO contact(name, designation) VALUES(%s, %s)', row)
	# 		row_count += 1

	# 	mydb.commit()
	# 	cursor.close()