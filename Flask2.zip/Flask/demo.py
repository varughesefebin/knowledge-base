from flask import Flask, render_template, request
import os
import pymysql

app = Flask(__name__)

@app.route('/')
def index():
	return render_template("index.html")

@app.route('/queryProcess', methods=['GET', 'POST'])
def queryProcess():
	if request.method == 'POST':
		query = request.form['query']
		token = query.split(' ')
		preposition = ['intercom', 'designation', 'number', 'in', 'on', 'to', 'of', 'for', 'that', 'the', 'with', 'by', 'at', 'a', 'is', 'what', 'where', 'how']

		processedToken = [elem for elem in token if elem not in preposition]
		print processedToken

		if 'list' in [x.lower() for x in processedToken]:

			facultyWebpages = ['www.karunya.edu/english/facultyprofile', 'www.karunya.edu/nanotechnology/facultyprofile', 'www.karunya.edu/maths/faculty', 'www.karunya.edu/emt/faculty', 'www.karunya.edu/eee/faculty', 'www.karunya.edu/civil/faculty', 'www.karunya.edu/agriculture/faculty', 'www.karunya.edu/cst/faculty', 'www.karunya.edu/ece/faculty', 'www.karunya.edu/mechanical/faculty', 'www.karunya.edu/bioinformatics/faculty', 'www.karunya.edu/eie/faculty', 'www.karunya.edu/chemistry/faculty']

			d = {}

			for item in facultyWebpages:
				d[item] = 0
			if processedToken != None:
				for i in range(len(processedToken)):
					for j in range(len(facultyWebpages)):
						if facultyWebpages[j].find(processedToken[i]) != -1:
							value = d.get(facultyWebpages[j])
							d[facultyWebpages[j]] = value + 1

			start_url = max(d, key=d.get)
			system_command = 'scrapy runspider grab.py -a url=http://' + start_url + ' -o static/feb.json'
			os.system("cd ~/Desktop/Flask")
			os.system("rm static/feb.json")
			os.system(system_command)
			os.system("sed -i '1i {\"feb\":' static/feb.json")
			os.system("echo '}' >> static/feb.json");
			return render_template('query-process.html', query="list")
		elif 'designation' in [x.lower() for x in token]:
			conn = pymysql.connect(host='localhost', user='root', password='', db='faculty')
			try:
				with conn.cursor() as cursor:
					query = "select * from contact where name like '%"
					for item in processedToken:
						query += str(item)
						query += " "
					query = query.rstrip()
					query += "%';"
					print query
					cursor.execute(query)
					result = cursor.fetchall()
					if result==None:
						return render_template('query-process.html', query="Error")
					else:
						return render_template('query-process.html', query="designation", name=result[0][0], designation=result[0][1])				
			finally:
				conn.close()
		elif 'intercom' in [x.lower() for x in token]:
			conn = pymysql.connect(host='localhost', user='root', password='', db='faculty')
			try:
				with conn.cursor() as cursor:
					query = "select * from intercom where description like '%"
					for item in processedToken:
						query += str(item)
						query += " "
					query = query.rstrip()
					query += "%';"
					print query
					cursor.execute(query)
					result = cursor.fetchone()
					if result==None:
						return render_template('query-process.html', query="Error")
					else:
						return render_template('query-process.html', query="intercom", name=result[0], designation=result[1])				
			finally:
				conn.close()
		else:
			return render_template('query-process.html',query='Given query cant be processed. Under Development!')
	return render_template('index.html')

if __name__ == "__main__":
	app.run(debug=False)