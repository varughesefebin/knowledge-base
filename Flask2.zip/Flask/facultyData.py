import os
import time
import json
import pymysql

# facultyWebpages = ['www.karunya.edu/english/facultyprofile', 'www.karunya.edu/nanotechnology/facultyprofile', 'www.karunya.edu/maths/faculty', 'www.karunya.edu/emt/faculty', 'www.karunya.edu/eee/faculty', 'www.karunya.edu/civil/faculty', 'www.karunya.edu/agriculture/faculty', 'www.karunya.edu/cst/faculty', 'www.karunya.edu/ece/faculty', 'www.karunya.edu/mechanical/faculty', 'www.karunya.edu/bioinformatics/faculty', 'www.karunya.edu/eie/faculty', 'www.karunya.edu/chemistry/faculty']

# os.system("rm ~/Desktop/Flask/static/faculty.json")

# for item in facultyWebpages:
# 	system_command = 'scrapy runspider grab.py -a url=http://' + item + ' -o static/faculty.json'
# 	os.system("cd ~/Desktop/Flask")
# 	os.system(system_command)
# 	time.sleep(.300)

# os.system("cd ~/Desktop/Flask")
# os.system("sed -i 's/\]/,/g' static/faculty.json")
# os.system("sed -i 's/\[//g' static/faculty.json")
# os.system("sed -i '1i [' static/faculty.json")
# os.system("sed -i '$d' static/faculty.json")
# os.system("echo ']' >> static/faculty.json");
f = open("static/faculty.json", "r")
s = f.read()
facultyJSON = json.loads(s)
print type(facultyJSON)

conn = pymysql.connect(host='localhost', user='root', password='', db='faculty')

try:
	with conn.cursor() as cursor:
		deleteQuery = "truncate table contact;"
		cursor.execute(deleteQuery)

		for item in facultyJSON:
			name = item['Name']
			desig = item['Designation']

			# print item

			query = "insert into contact values(%s, %s);"
			cursor.execute(query, (name, desig))
			conn.commit()
finally:
	conn.close()