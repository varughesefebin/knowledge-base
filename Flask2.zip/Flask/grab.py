# -*- coding: utf-8 -*-
import scrapy

from scrapy import Spider


class GrabSpider(Spider):
    name = 'grab'

    url_start=''

    def __init__(self, url=None, *args, **kwargs):
    	super(GrabSpider, self).__init__(*args, **kwargs)
    	self.start_urls = ["%s" % url]
        url_start = self.start_urls


    allowed_domains = ['karunya.edu/']
    # self.start_urls = [domain]
    # email_one = ['civil', 'eee']

    def parse(self, response):
        special_one = ['chemistry']
        testimonial_author = ['cst', 'agriculture', 'bioinformatics', 'civil', 'ece', 'eee', 'eie', 'emt', 'maths', 'mechanical', 'nanotechnology']
        english = ['english']
    	if any(x in response.url for x in testimonial_author):
            container = response.xpath('//*[@class="testimonial-author"]')
            for contain in container:
                faculty_name = contain.xpath('.//strong/text()').extract_first()
                designation = contain.xpath('.//span/text()').extract_first()
                yield{'Name': faculty_name, 'Designation': designation}
        elif any(x in self.start_urls for x in special_one):
            container = response.xpath('//*[@class="testimonial-author"]')
            faculty_name = container[0].xpath('.//b/text()').extract_first()
            designation = container[0].xpath('.//span/text()').extract_first()
	    	# expertise = container[0].xpath('.//span/text()[2]').extract_first()
            yield{'Name': faculty_name, 'Designation': designation}
            for contain in islice(container, 1, None):
                faculty_name = contain.xpath('.//b/text()').extract_first()
                designation = contain.xpath('.//text()[2]').extract_first()
                yield{'Name': faculty_name, 'Designation': designation}
        else:
            container = response.xpath('//*[@class="chip"]')
            for contain in container:
                faculty_name = contain.xpath('.//b/text()').extract_first()
                designationAndExpertise = contain.xpath('.//text()[3]').extract_first()
                yield{'Name':faculty_name, 'Designation': designationAndExpertise}
			
		    # 	expertise = contain.xpath('.//text()[3]').extract_first()
	    	# if(expertise=="Non Teaching Staff"):
	    	# 	expertise = None
		# else any(x in self.start_urls for x in english):
	 #    else:
	 #    	pass
					


	# def close(self, reason):
	# 	csv_file = max(glob.iglob('*.csv'), key=os.path.getctime)

	# 	mydb = MySQLdb.connect(host='localhost', user='root', passwd=null, db='faculty')

	# 	cursor = mydb.cursor()

	# 	csv_data = csv.reader(file(csv_file))

	# 	row_count = 0
	# 	for row in csv_data:
	# 		if row_count != 0:
	# 			cursor.execute('INSERT IGNORE INTO contact(name, designation) VALUES(%s, %s)', row)
	# 		row_count += 1

	# 	mydb.commit()
	# 	cursor.close()