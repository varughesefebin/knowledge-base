$.ajax({
	url: '{{ url_for('static', filename='feb.json') }}',
	dataType: 'json',
	type: 'get',
	cache: false,
	success: function(data) {
		$(data.feb).each(function(index, value) {
			console.log(value.name);
		});
	}
});