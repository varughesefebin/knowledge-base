text = "Hello all "

text = text.rstrip()
text+="%"
print text