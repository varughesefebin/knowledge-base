# -*- coding: utf-8 -*-
import scrapy


class AgricultureSpider(scrapy.Spider):
    name = 'agriculture'
    allowed_domains = ['karunya.edu/agriculture/faculty']
    start_urls = ['http://karunya.edu/agriculture/faculty/']

    def parse(self, response):
        container = response.xpath('//*[@class="testimonial-author"]')
        for contain in container:
        	faculty_name = contain.xpath('.//strong/text()').extract_first()
        	designation = contain.xpath('.//span/text()').extract_first()
        	expertise = contain.xpath('.//span/text()[2]').extract_first()

        	yield{'name': faculty_name, 'designation': designation, 'expertise': expertise}
