# -*- coding: utf-8 -*-
import scrapy
from itertools import islice

class ChemistrySpider(scrapy.Spider):
    name = 'chemistry'
    allowed_domains = ['karunya.edu/chemistry/faculty']
    start_urls = ['http://karunya.edu/chemistry/faculty/']

    def parse(self, response):
        container = response.xpath('//*[@class="testimonial-author"]')

        #Due to poor structure (asymmetrical layout) of the webpage a seperate stub to handle the situation
    	faculty_name = container[0].xpath('.//b/text()').extract_first()
    	designation = container[0].xpath('.//span/text()').extract_first()
    	expertise = container[0].xpath('.//span/text()[2]').extract_first()

    	yield{'Name': faculty_name, 'Designation': designation, 'Expertise': expertise}
    	#-------------------------------------------------------------------------------------------

    	#for the rest of the webpage with symmetrical html structure
        for contain in islice(container, 1, None):
        	faculty_name = contain.xpath('.//b/text()').extract_first()
        	designation = contain.xpath('.//text()[2]').extract_first()
        	expertise = contain.xpath('.//text()[3]').extract_first()

        	if(expertise=="Non Teaching Staff"):
        		expertise = None

        	yield{'Name': faculty_name, 'Designation': designation, 'Expertise': expertise}