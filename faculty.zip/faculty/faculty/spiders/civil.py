# -*- coding: utf-8 -*-
import scrapy


class CivilSpider(scrapy.Spider):
    name = 'civil'
    allowed_domains = ['karunya.edu/civil/faculty']
    start_urls = ['http://karunya.edu/civil/faculty/']

    def parse(self, response):
    	container = response.xpath('//*[@class="testimonial-author"]')
        for contain in container:
        	faculty_name = contain.xpath('.//strong/text()').extract_first()
        	designation = contain.xpath('.//span/text()').extract_first()
        	email = contain.xpath('.//span/text()[2]').extract_first()

        	yield{'Name': faculty_name, 'Designation': designation, 'Email': email}