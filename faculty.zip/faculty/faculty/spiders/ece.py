# -*- coding: utf-8 -*-
import scrapy


class EceSpider(scrapy.Spider):
    name = 'ece'
    allowed_domains = ['karunya.edu/ece/faculty']
    start_urls = ['http://karunya.edu/ece/faculty/']

    def parse(self, response):
        container = response.xpath('//*[@class="testimonial-author"]')
        for contain in container:
        	faculty_name = contain.xpath('.//strong/text()').extract_first()
        	yield{'name':faculty_name}
