# -*- coding: utf-8 -*-
import scrapy


class EeeSpider(scrapy.Spider):
    name = 'eee'
    allowed_domains = ['karunya.edu/eee/faculty']
    start_urls = ['http://karunya.edu/eee/faculty/']

    def parse(self, response):
        container = response.xpath('//*[@class="testimonial-author"]')
        for contain in container:
        	faculty_name = contain.xpath('.//strong/text()').extract_first()
        	yield{'name':faculty_name}
