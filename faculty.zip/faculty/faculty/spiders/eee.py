# -*- coding: utf-8 -*-
import scrapy


class EeeSpider(scrapy.Spider):
    name = 'eee'
    allowed_domains = ['karunya.edu/eee/faculty']
    start_urls = ['http://karunya.edu/eee/faculty/']

    def parse(self, response):
        container = response.xpath('//*[@class="testimonial-author"]')
        for contain in container:
        	faculty_name = contain.xpath('.//strong/text()').extract_first()
        	designation = contain.xpath('.//span/text()').extract_first()
        	email = contain.xpath('.//span/text()[2]').extract_first()
        	expertise = contain.xpath('.//span/text()[3]').extract_first()

        	yield{'Name': faculty_name, 'Designation': designation, 'Expertise': expertise, 'Email':email}
