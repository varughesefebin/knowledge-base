# -*- coding: utf-8 -*-
import scrapy


class EieSpider(scrapy.Spider):
    name = 'eie'
    allowed_domains = ['karunya.edu/eie/faculty']
    start_urls = ['http://karunya.edu/eie/faculty/']

    def parse(self, response):
        container = response.xpath('//*[@class="testimonial-author"]')
        for contain in container:
        	faculty_name = contain.xpath('.//strong/text()').extract_first()
        	designation = contain.xpath('.//span/text()').extract_first()
        	email = contain.xpath('.//span/text()[2]').extract_first()
        	expertise = contain.xpath('.//span/i/small/text()').extract_first()[18:]		#slicing
        	# expertise[18:]
        	# expertise = temp
        	expertise = expertise.strip()			#strip() to remove whitespaces
        	if expertise.startswith(":"):
        		expertise = expertise[2:]
        	yield{'Name': faculty_name, 'Designation': designation, 'Expertise': expertise, 'Email':email}
