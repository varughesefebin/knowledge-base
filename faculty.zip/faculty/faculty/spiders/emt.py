# -*- coding: utf-8 -*-
import scrapy


class EmtSpider(scrapy.Spider):
    name = 'emt'
    allowed_domains = ['karunya.edu/emt/faculty']
    start_urls = ['http://karunya.edu/emt/faculty/']

    def parse(self, response):
        container = response.xpath('//*[@class="testimonial-author"]')
        for contain in container:
        	faculty_name = contain.xpath('.//strong/text()').extract_first()
        	designation = contain.xpath('.//span/text()').extract_first()
        	email = contain.xpath('.//span/text()[2]').extract_first()
        	expertise = contain.xpath('.//span/span/text()').extract_first()

        	yield{'Name': faculty_name, 'Designation': designation, 'Expertise': expertise, 'Email':email}


