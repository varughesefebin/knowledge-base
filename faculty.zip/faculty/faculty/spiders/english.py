# -*- coding: utf-8 -*-
import scrapy


class EnglishSpider(scrapy.Spider):
    name = 'english'
    allowed_domains = ['karunya.edu/english/facultyprofile']
    start_urls = ['http://karunya.edu/english/facultyprofile/']

    def parse(self, response):
        container = response.xpath('//*[@class="chip"]')
        for contain in container:
        	faculty_name = contain.xpath('.//b/text()').extract_first()
        	designationAndExpertise = container.xpath('.//*[@class="img-circle"]/text()[1]').extract_first()

        	yield{'name':faculty_name, 'Designation And Expertise': designationAndExpertise}
