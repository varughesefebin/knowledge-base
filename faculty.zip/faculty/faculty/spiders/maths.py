# -*- coding: utf-8 -*-
import scrapy


class MathsSpider(scrapy.Spider):
    name = 'maths'
    allowed_domains = ['karunya.edu/maths/faculty']
    start_urls = ['http://karunya.edu/maths/faculty/']

    def parse(self, response):
        container = response.xpath('//*[@class="testimonial-author"]')
        for contain in container:
        	faculty_name = contain.xpath('.//strong/text()').extract_first()
        	designation = contain.xpath('.//span/text()').extract_first()

        	yield{'Name': faculty_name, 'Designation': designation}
