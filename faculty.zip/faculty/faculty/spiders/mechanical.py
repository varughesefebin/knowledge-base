# -*- coding: utf-8 -*-
import scrapy


class MechanicalSpider(scrapy.Spider):
    name = 'mechanical'
    allowed_domains = ['karunya.edu/mechanical/faculty']
    start_urls = ['http://karunya.edu/mechanical/faculty/']

    def parse(self, response):
        container = response.xpath('//*[@class="testimonial-author"]')
        for contain in container:
        	faculty_name = contain.xpath('.//strong/text()').extract_first()
        	designation = contain.xpath('.//span/text()').extract_first()
        	email = contain.xpath('.//span/text()[2]').extract_first()

        	yield{'Name': faculty_name, 'Designation': designation, 'Email': email}