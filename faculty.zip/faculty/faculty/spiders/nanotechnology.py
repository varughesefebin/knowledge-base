# -*- coding: utf-8 -*-
import scrapy


class NanotechnologySpider(scrapy.Spider):
    name = 'nanotechnology'
    allowed_domains = ['karunya.edu/nanotechnology/facultyprofile']
    start_urls = ['http://karunya.edu/nanotechnology/facultyprofile/']

    def parse(self, response):
        container = response.xpath('//*[@class="testimonial-author"]')
        for contain in container:
        	faculty_name = contain.xpath('.//strong/text()').extract_first()
        	yield{'name':faculty_name}
